# Example Package

Module 02 Ex04 of the IBM / 42 Python Bootcamp
Building a PyPI package